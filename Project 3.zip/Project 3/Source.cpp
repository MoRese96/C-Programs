#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <limits> // For input validation

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;
    string dataFilePath;

public:
    ItemTracker() {
        dataFilePath = "frequency.dat";
    }

    void processInputFile(const string& filePath) {
        ifstream inputFile(filePath);
        if (!inputFile) {
            cerr << "Error: Unable to open file " << filePath << endl;
            exit(1); // Exit program if file cannot be read
        }

        string item;
        while (getline(inputFile, item)) {
            itemFrequency[item]++;
        }
        inputFile.close();
    }

    void saveDataToFile() {
        ofstream outputFile(dataFilePath);
        if (!outputFile) {
            cerr << "Error: Unable to create output file " << dataFilePath << endl;
            return;
        }

        for (const auto& pair : itemFrequency) {
            outputFile << pair.first << " " << pair.second << endl;
        }
        outputFile.close();
        cout << "Data saved to " << dataFilePath << endl;
    }

    void printItemFrequency() const {
        if (itemFrequency.empty()) {
            cout << "No data available.\n";
            return;
        }

        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void printHistogram() const {
        if (itemFrequency.empty()) {
            cout << "No data available.\n";
            return;
        }

        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << string(pair.second, '*') << endl;
        }
    }

    void run() {
        string userInput;
        int choice;

        do {
            cout << "\nMenu Options:\n";
            cout << "1. Look up item frequency\n";
            cout << "2. Print item frequency list\n";
            cout << "3. Print item frequency histogram\n";
            cout << "4. Exit\n";
            cout << "Enter your choice: ";

            if (!(cin >> choice)) {
                cout << "Invalid input! Please enter a number between 1 and 4.\n";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear invalid input
                continue;
            }

            switch (choice) {
            case 1:
                cout << "Enter the item to look up: ";
                cin.ignore(); // Ignore leftover newline
                getline(cin, userInput);

                if (itemFrequency.find(userInput) != itemFrequency.end()) {
                    cout << "Frequency of " << userInput << ": " << itemFrequency[userInput] << endl;
                }
                else {
                    cout << userInput << " not found.\n";
                }
                break;
            case 2:
                printItemFrequency();
                break;
            case 3:
                printHistogram();
                break;
            case 4:
                saveDataToFile();
                cout << "Exiting program.\n";
                break;
            default:
                cout << "Invalid choice. Please enter a number between 1 and 4.\n";
                break;
            }
        } while (choice != 4);
    }
};

int main() {
    string inputFile = "CS210_Project_Three_Input_File.txt";
    ItemTracker tracker;
    tracker.processInputFile(inputFile);
    tracker.run();

    return 0;
}
