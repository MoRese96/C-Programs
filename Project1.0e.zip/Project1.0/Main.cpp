#include <iostream>
#include <iomanip>
using namespace std;

// Class to handle the clock
class Clock {
private:
    int hours;
    int minutes;
    int seconds;

    void incrementHours() {
        hours = (hours + 1) % 24;
    }

    void incrementMinutes() {
        minutes++;
        if (minutes == 60) {
            minutes = 0;
            incrementHours();
        }
    }

    void incrementSeconds() {
        seconds++;
        if (seconds == 60) {
            seconds = 0;
            incrementMinutes();
        }
    }

public:
    // Constructor to initialize the clock
    Clock(int h = 0, int m = 0, int s = 0) : hours(h), minutes(m), seconds(s) {}

    void addHour() {
        incrementHours();
    }

    void addMinute() {
        incrementMinutes();
    }

    void addSecond() {
        incrementSeconds();
    }

    void display12HourFormat() const {
        int displayHours = hours % 12;
        if (displayHours == 0) displayHours = 12; // Handle midnight/noon case
        string period = (hours >= 12) ? "PM" : "AM";

        cout << "   12-Hour Clock: "
            << setw(2) << setfill('0') << displayHours << ":"
            << setw(2) << setfill('0') << minutes << ":"
            << setw(2) << setfill('0') << seconds << " " << period << endl;
    }

    void display24HourFormat() const {
        cout << "   24-Hour Clock: "
            << setw(2) << setfill('0') << hours << ":"
            << setw(2) << setfill('0') << minutes << ":"
            << setw(2) << setfill('0') << seconds << endl;
    }
};

void displayMenu() {
    cout << "\n**************************" << endl;
    cout << "* 1 - Add One Hour       *" << endl;
    cout << "* 2 - Add One Minute     *" << endl;
    cout << "* 3 - Add One Second     *" << endl;
    cout << "* 4 - Exit Program       *" << endl;
    cout << "**************************" << endl;
    cout << "Enter your choice: ";
}

int main() {
    Clock clock(12, 0, 0); // Initialize the clock at noon
    int choice;

    do {
        system("clear"); // Clear the screen (use "cls" on Windows)
        clock.display12HourFormat();
        clock.display24HourFormat();

        displayMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            clock.addHour();
            break;
        case 2:
            clock.addMinute();
            break;
        case 3:
            clock.addSecond();
            break;
        case 4:
            cout << "Exiting program..." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 4);

    return 0;
}
