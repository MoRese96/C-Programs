#include <iomanip>  // For setting precision

using namespace std;

// Function to calculate the balance without monthly deposit
double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double annualInterestRate, int numberOfYears) {
    double balance = initialInvestment;
    double monthlyInterestRate = (annualInterestRate / 100) / 12;

    // Loop through each year
    for (int year = 1; year <= numberOfYears; ++year) {
        double interestEarnedThisYear = 0;
        // Compound the interest monthly for each year
        for (int month = 1; month <= 12; ++month) {
            double interestThisMonth = balance * monthlyInterestRate;
            balance += interestThisMonth;
            interestEarnedThisYear += interestThisMonth;
        }

        // Print details for the year using the provided function
        printDetails(year, balance, interestEarnedThisYear);
    }

    return balance; // Return the final balance after all the years
}
