/**
 * Calculates and returns an end of year balance for a given number of years
 *
 * @param initialInvestment dollar amount of initial investment
 * @param monthlyDeposit dollar amount added into the investment each month
 * @param interestRate percentage of investment earned each year (annually), so a passed value of 3.5 is a rate of .035
 * @param numberOfYears number of years to calculate balance for
 *
 * @return the final calculated end of year balance
 */
double balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) {
    // you may wish to change this function when you bring it into your program
    // for now  please get it to work here as specified in this function header

    //       IMPORTANT TIPS:
    // You may assume a working printDetails(int yearIndex, double balance, double interestEarnedThisYear) exists
    // printDetails should be called after each year
    // Compounding should be done monthly
    // Make sure to divide the interest rate by 100 and by 12
    // This month's deposit does not earn interest(until next month)
    // Year begins with 1, not 0

    /*
    Example for 100 initial investment and 10% interest and $10 monthly payment:
    Year            Year End Balance        Interest Earned
     1               	$236.13                 	$16.13
     2                  $386.51                	    $30.38
     3               	$552.64                 	$46.13
     4              	$736.16                 	$63.52
    */

    // TODO: your code here to implement the method
#include <iostream>
#include <iomanip>  // For setting precision

    using namespace std;

    // Function to calculate balance with monthly deposits
    double balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) {
        double Balance = initialInvestment;  // Initialize balance
        double monthlyInterestRate = (interestRate / 100.0) / 12.0;  // Convert annual rate to monthly rate

        // Loop through each year
        for (int year = 1; year <= numberOfYears; ++year) {
            double interestEarnedThisYear = 0;  // Reset yearly interest

            // Loop through each month
            for (int month = 1; month <= 12; ++month) {
                double interestThisMonth = balance * monthlyInterestRate;  // Calculate interest
                balance += interestThisMonth;  // Apply interest
                interestEarnedThisYear += interestThisMonth;
                balance += monthlyDeposit;  // Add deposit after interest
            }

            // Print details for the year
            printDetails(year, balance, interestEarnedThisYear);
        }

        return balance;  // Return the final balance
    }

    // Main function to test
    int main() {
        double initialInvestment = 100.0;
        double monthlyDeposit = 10.0;
        double interestRate = 10.0;
        int numberOfYears = 4;

        balanceWithMonthlyDeposit(initialInvestment, monthlyDeposit, interestRate, numberOfYears);

        return 0;
    }