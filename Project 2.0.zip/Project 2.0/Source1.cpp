#include <iostream>
#include <iomanip>  // For setting precision

using namespace std;

/**
* Prints the calculated results of each year's investment details in 3 separate fields.
* @param year year number
* @param yearEndBalance the current dollar value of the investment
* @param interestEarned dollar amount of how much earned in that year
*/
void printDetails(int year, double yearEndBalance, double interestEarned) {
    // Print the details: year, year-end balance, interest earned with proper formatting
    cout << year << "\t\t$" << fixed << setprecision(2) << yearEndBalance
        << "\t\t$" << fixed << setprecision(2) << interestEarned << endl;
}
