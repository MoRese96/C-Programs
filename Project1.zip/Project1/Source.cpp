#include <iostream>
using namespace std;

void main()
{
	cout << "This is a test" << endl;

	return 0;
}